To download and run the NutritionFreak.apk:
1.	You have an android phone:
a)	Easiest: If you have an android phone you can download the .apk from your phone. Go to https://drive.google.com/drive/u/0/folders/0B4zxRDgFLe-CblRTdktBbDdvdlE and simply download the .apk on your phone and install.
b)	If you have an android phone you can download the NutritionFreak.apk file onto your PC/Mac and transfer it onto the android phone. First, connect your android device into a PC or Mac via USB. In the internal storage of your phone and navigate to the Download folder. Next, copy and paste the .apk file into the Download folder in the android. Disconnect your phone from the computer. Note: Make sure you have Unknown source enabled on your phone (Settings -> Security -> Unknown sources).Using a file manager on your phone (we used File Manager by ZenUI but any file manager will do) navigate to the Download folder on your android device and tap on the .apk file. At this point you should be promoted to install the app. Install the app, and launch it.
c)	If the above did not work try:
-	https://www.youtube.com/watch?v=nY5EY1JWOaw
-	http://science.opposingviews.com/move-apk-files-pc-android-phone-16071.html


2.	You do not have an android phone:
I used a Genymotion emulator. It�s free and its fast: https://www.genymotion.com/
a)	https://www.youtube.com/watch?v=PoS2Vzt395I
b)	http://stackoverflow.com/questions/3480201/how-do-you-install-an-apk-file-in-the-android-emulator
c)	Google search 

3.	Last Case: Download Android studio and import the Android Studio project:
a)	http://developer.android.com/sdk/index.html
a.	https://www.jetbrains.com/help/idea/2016.1/importing-an-existing-android-project.html?origin=old_help
